"""
References:
    http://bindpose.com/creating-maya-control-shape-manager
    https://bindpose.com/scripting-custom-shelf-in-maya-python/
"""

from maya import cmds as mc, OpenMaya as om

import functools
import json
import os
import re
import sys


####################################################################
PROJECT_PATH = '/Users/nicholashomefolder/CurveManager'
ICON_PATH = PROJECT_PATH + "/icons/"
CURVE_LIBRARY_PATH = PROJECT_PATH + "/curve_library/"

curve_clipboard = None


def validate_path(path=None):
    """Checks if the file already exists and provides a dialog to overwrite or not"""
    if os.path.isfile(path):
        confirm = mc.confirmDialog(title='Overwrite file?',
                                   message='The file ' + path + ' already exists.Do you want to overwrite it?',
                                   button=['Yes', 'No'],
                                   defaultButton='Yes',
                                   cancelButton='No',
                                   dismissString='No')
        if confirm == "No":
            mc.warning("The file " + path + " was not saved")
            return 0
    return 1


def load_data(path=None):
    """Loads raw JSON data from a file and returns it as a dict"""
    if os.path.isfile(path):
        f = open(path, "r")
        data = json.loads(f.read())
        f.close()
        return data
    else:
        mc.error("The file " + path + " doesn't exist")


def save_json(path=None, data=None):
    """Saves a dictionary as JSON in a file"""
    if validate_path(path):
        with open(path, "w") as f:
            f.write(json.dumps(data, sort_keys=1, indent=4, separators=(",", ":")))
        return 1
    return 0


def get_knots(curve=None):
    obj = om.MObject()
    sel = om.MSelectionList()
    sel.add(curve)
    sel.getDependNode(0, obj)

    fnCurve = om.MFnNurbsCurve(obj)
    tmpKnots = om.MDoubleArray()
    fnCurve.getKnots(tmpKnots)

    return [tmpKnots[i] for i in range(tmpKnots.length())]


def get_curve(curve=None):
    """Returns a dictionary containing all the necessary information for rebuilding the passed in crv."""
    curves = validate_curve(curve)

    curve_list = []

    for curve in curves:
        curve_dict = {
            "points": [],
            "knots": [],
            "form": mc.getAttr(curve + ".form"),
            "degree": mc.getAttr(curve + ".degree"),
            "color": mc.getAttr(curve + ".overrideColor")
        }
        points = []

        for i in range(mc.getAttr(curve + ".controlPoints", s=1)):
            points.append(mc.getAttr(curve + ".controlPoints[%i]" % i)[0])

        curve_dict["points"] = points
        curve_dict["knots"] = get_knots(curve)

        curve_list.append(curve_dict)

    return curve_list


def set_curve(curve, curve_list):
    """Creates a new curve on the crv transform, using the properties in the curveDict."""
    curves = validate_curve(curve)

    old_color = mc.getAttr(curves[0] + ".overrideColor")
    mc.delete(curves)

    for i, curveDict in enumerate(curve_list):
        tmpCurve = mc.curve(p=curveDict["points"], k=curveDict["knots"], d=curveDict["degree"],
                          per=bool(curveDict["form"]))
        new_curve = mc.listRelatives(tmpCurve, s=1)[0]
        mc.parent(new_curve, curve, r=1, s=1)

        mc.delete(tmpCurve)
        new_curve = mc.rename(new_curve, curve + "Shape" + str(i + 1).zfill(2))

        mc.setAttr(new_curve + ".overrideEnabled", 1)

        if "color" in curveDict.keys():
            set_color(new_curve, curveDict["color"])
        else:
            set_color(new_curve, old_color)


def validate_curve(curve=None):
    """Checks whether the transform we are working with is actually a curve and returns it's curves"""
    if mc.nodeType(curve) == "transform" and mc.nodeType(mc.listRelatives(curve, c=1, s=1)[0]) == "nurbsCurve":
        curves = mc.listRelatives(curve, c=1, s=1)
    elif mc.nodeType(curve) == "nurbsCurve":
        curves = mc.listRelatives(mc.listRelatives(curve, p=1)[0], c=1, s=1)
    else:
        mc.error("The object " + curve + " passed to validateCurve() is not a curve")
    return curves


def load_from_lib(curve=None):
    """Loads the curve data from the curve file in the CURVE_LIBRARY_PATH directory"""
    path = os.path.join(CURVE_LIBRARY_PATH, curve + ".json")
    data = load_data(path)
    return data


def save_to_lib(curve=None, curveName=None):
    """Saves the curve data to a curve file in the CURVE_LIBRARY_PATH directory"""
    curve = get_curve(curve=curve)
    path = os.path.join(CURVE_LIBRARY_PATH, re.sub("\s", "", curveName) + ".json")
    for curveDict in curve:
        curveDict.pop("", None)
    save_json(path, curve)


def set_color(curve, color):
    """Sets the overrideColor of a curve"""
    if mc.nodeType(curve) == "transform":
        curves = mc.listRelatives(curve)
    else:
        curves = [curve]
    for curve in curves:
        mc.setAttr(curve + ".overrideColor", color)


def get_available_curves():
    """Returns a list of the available curves in the specified library. Each element
    of the list is a tuple containing the label (name) of the curve and a reference
    to the command to assign that curve via functools.partial"""
    lib = CURVE_LIBRARY_PATH
    return [(x.split(".")[0], functools.partial(assign_curve, x.split(".")[0])) for x in os.listdir(lib)]


def get_available_colors():
    """Returns a list of the available 32 colous for overrideColor in maya. Each element
    of the list is a tuple containig the label, reference to the command which assigns the
    color and the name of an image to be used as an icon"""
    return [("color" + str(i).zfill(2), functools.partial(assign_color, i), "color" + str(i).zfill(2) + ".png") for
            i in range(32)]


def assign_color(*args):
    """Assigns args[0] as the overrideColor of the selected curves"""
    for each in mc.ls(sl=1, fl=1):
        set_color(each, args[0])


def assign_curve(*args):
    """Assigns args[0] as the curve of the selected curves"""
    sel = mc.ls(sl=1, fl=1)
    for each in sel:
        set_curve(each, load_from_lib(args[0]))
    mc.select(sel)


def save_curve_to_lib(*args):
    """Saves the selected curve in the defined curved library"""
    result = mc.promptDialog(title="Save Curve to Library",
                             m="Curve Name",
                             button=["Save", "Cancel"],
                             cancelButton="Cancel",
                             dismissString="Cancel")
    if result == "Save":
        try:
            name = mc.promptDialog(q=1, t=1)
            save_to_lib(mc.ls(sl=1, fl=1)[0], name)
        except:
            mc.warning("Failed: No curves selected")
    rebuild_ui()


def copy_curve(*args):
    """Copies the selected curve to a global variable for pasting"""
    global curve_clipboard
    curve_clipboard = get_curve(mc.ls(sl=1, fl=1)[0])
    for curve in curve_clipboard:
        curve.pop("color")


def paste_curve(*args):
    """Assigns the curve from the curve_clipboard global variable to the selected curves"""
    sel = mc.ls(sl=1, fl=1)
    for each in sel:
        set_curve(each, curve_clipboard)
    mc.select(sel)


def flip_curve(*args):
    """Flips the selected curves to the other side in all axis"""
    sel = mc.ls(sl=1, fl=1)
    for each in sel:
        _flip_curve(each)
    mc.select(sel)


def flip_curve_x(*args):
    """Flips the selected curves to the other side in X"""
    sel = mc.ls(sl=1, fl=1)
    for each in sel:
        _flip_curve(each, [-1, 1, 1])
    mc.select(sel)


def flip_curve_y(*args):
    """Flips the selected curves to the other side in Y"""
    sel = mc.ls(sl=1, fl=1)
    for each in sel:
        _flip_curve(each, [1, -1, 1])
    mc.select(sel)


def flip_curve_z(*args):
    """Flips the selected curves to the other side in Z"""
    sel = mc.ls(sl=1, fl=1)
    for each in sel:
        _flip_curve(each, [1, 1, -1])
    mc.select(sel)


def _flip_curve(curve=None, axis=[-1, -1, -1]):
    """Scales the points of the crv argument by the axis argument. This function is not meant to be
    called directly. Look at the flip_curve instead."""
    curves = get_curve(curve)
    new_curves = []
    for c in curves:
        for i, each in enumerate(c["points"]):
            c["points"][i] = [each[0] * axis[0], each[1] * axis[1], each[2] * axis[2]]
        new_curves.append(c)
    set_curve(curve, new_curves)
    mc.select(curve)


def rebuild_ui(*args):
    mc.evalDeferred("""
sys.path.append(PROJECT_PATH)
import curve_manager
reload(curve_manager)
""")

####################################################################


def _null(*args):
    pass


class _Shelf():
    """A simple class to build shelves in maya. Since the build method is empty,
    it should be extended by the derived class to build the necessary shelf elements.
    By default it creates an empty shelf called "CustomShelf"."""

    def __init__(self, name="CustomShelf", icon_path=""):
        self.name = name

        # self.iconPath = iconPath

        self.labelBackground = (0, 0, 0, 0)
        self.labelColour = (.9, .9, .9)

        self._clean_old_shelf()
        mc.setParent(self.name)
        self.build()

    def build(self):
        """This method should be overwritten in derived classes to actually build the shelf
        elements. Otherwise, nothing is added to the shelf."""
        pass

    def add_button(self, label, icon="commandButton.png", command=_null, double_command=_null):
        """Adds a shelf button with the specified label, command, double click command and image."""
        mc.setParent(self.name)
        mc.shelfButton(width=37, height=37, image=icon, l=label, command=command, dcc=double_command,
                       imageOverlayLabel=label, olb=self.labelBackground, olc=self.labelColour)

    def _clean_old_shelf(self):
        """Checks if the shelf exists and empties it if it does or creates it if it does not."""
        if mc.shelfLayout(self.name, ex=1):
            if mc.shelfLayout(self.name, q=1, ca=1):
                for each in mc.shelfLayout(self.name, q=1, ca=1):
                    mc.deleteUI(each)
        else:
            mc.shelfLayout(self.name, p="ShelfLayout")


class CurveManager(_Shelf):
    def build(self):
        self.add_button("Funcs")

        popup_menu = mc.popupMenu(b=1)  # b=1: left mouse click; 2: middle; 3: right

        mc.menuItem(p=popup_menu, l="Save To Library", c=save_curve_to_lib)  # p: parent; l: label; c: command

        sub_menu = mc.menuItem(p=popup_menu, l="Assign From Library", subMenu=True)
        for curve in get_available_curves():
            mc.menuItem(p=sub_menu, l=curve[0], c=curve[1])

        mc.menuItem(p=popup_menu, l="Copy", c=copy_curve)
        mc.menuItem(p=popup_menu, l="Paste", c=paste_curve)

        sub_menu = mc.menuItem(p=popup_menu, l="Set Color", subMenu=True)
        for color in get_available_colors():
            mc.menuItem(p=sub_menu, l=color[0], c=color[1], i=ICON_PATH + color[2])

        sub_menu = mc.menuItem(p=popup_menu, l="Flip", subMenu=True)
        mc.menuItem(p=sub_menu, l="Flip X", c=flip_curve_x)
        mc.menuItem(p=sub_menu, l="Flip Y", c=flip_curve_y)
        mc.menuItem(p=sub_menu, l="Flip Z", c=flip_curve_z)
        mc.menuItem(p=sub_menu, l="Flip XYZ", c=flip_curve)


CurveManager('CurveManager')
